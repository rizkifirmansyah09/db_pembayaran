--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.tb_admin DROP CONSTRAINT tb_admin_pkey;
ALTER TABLE ONLY public.tarif DROP CONSTRAINT tarif_pkey;
ALTER TABLE ONLY public.tagihan DROP CONSTRAINT tagihan_pkey;
ALTER TABLE ONLY public.penggunaan DROP CONSTRAINT penggunaan_pkey;
ALTER TABLE ONLY public.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_pkey;
DROP TABLE public.tb_level;
DROP TABLE public.tb_admin;
DROP TABLE public.tarif;
DROP TABLE public.tagihan;
DROP TABLE public.penggunaan;
DROP TABLE public.pembayaran;
DROP TABLE public.pelanggan;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pelanggan (
    id_pelanggan character varying(50) NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    nomor_kwh integer NOT NULL,
    nama_pelanggan character varying(100) NOT NULL,
    alamat character varying(200) NOT NULL,
    id_tarif character varying(50) NOT NULL
);


ALTER TABLE pelanggan OWNER TO postgres;

--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembayaran (
    id_pembayaran character varying(50) NOT NULL,
    id_tagihan character varying(50) NOT NULL,
    id_pelanggan character varying(50) NOT NULL,
    tanggal_pembayaran date NOT NULL,
    bulan_bayar date NOT NULL,
    biaya_admin integer NOT NULL,
    total_bayar integer NOT NULL,
    id_admin character varying(50) NOT NULL
);


ALTER TABLE pembayaran OWNER TO postgres;

--
-- Name: penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE penggunaan (
    id_penggunaan character varying(50) NOT NULL,
    id_pelanggan character varying(50) NOT NULL,
    bulan character varying(100) NOT NULL,
    tahun character varying NOT NULL,
    meter_awal integer NOT NULL,
    meter_akhir integer NOT NULL
);


ALTER TABLE penggunaan OWNER TO postgres;

--
-- Name: tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tagihan (
    id_tagihan character varying(50) NOT NULL,
    id_pengunaan character varying(50) NOT NULL,
    id_pelanggan character varying(50) NOT NULL,
    bulan character varying(100) NOT NULL,
    tahun character varying(100) NOT NULL,
    jumlah_meter integer NOT NULL,
    status character varying(100) NOT NULL
);


ALTER TABLE tagihan OWNER TO postgres;

--
-- Name: tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tarif (
    id_tarif character varying(50) NOT NULL,
    daya character varying(100) NOT NULL,
    tarifperkwh integer NOT NULL
);


ALTER TABLE tarif OWNER TO postgres;

--
-- Name: tb_admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_admin (
    id_admin character varying(50) NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    nama_admin character varying(100) NOT NULL,
    id_level character varying(50) NOT NULL
);


ALTER TABLE tb_admin OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(50) NOT NULL,
    nama_level character varying(100) NOT NULL
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY pelanggan (id_pelanggan, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM stdin;
\.
COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_bayar, id_admin) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tagihan (id_tagihan, id_pengunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tagihan (id_tagihan, id_pengunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: tb_admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2834.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2835.dat';

--
-- Name: pelanggan pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_pkey PRIMARY KEY (id_pelanggan);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: penggunaan penggunaan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penggunaan
    ADD CONSTRAINT penggunaan_pkey PRIMARY KEY (id_penggunaan);


--
-- Name: tagihan tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan
    ADD CONSTRAINT tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: tarif tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tarif
    ADD CONSTRAINT tarif_pkey PRIMARY KEY (id_tarif);


--
-- Name: tb_admin tb_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_admin
    ADD CONSTRAINT tb_admin_pkey PRIMARY KEY (id_admin);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- PostgreSQL database dump complete
--

